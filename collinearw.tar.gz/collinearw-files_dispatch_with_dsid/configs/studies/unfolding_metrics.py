import collinearw

from collinearw.strategies import unfolding

def main():

    config = collinearw.ConfigMgr.open("merged.pkl")

    name_map = {"wjets"              : "Sherpa 2.2.1",
                "wjets_FxFx"         : "MadGraph+Pythia8 FxFx",
                "wjets_2211"         : "Sherpa 2.2.11 NLO QCD",
                "wjets_2211_ASSEW"   : "Sherpa 2.2.11 NLO QCD+EW" } 

    collinearw.run_PlotMaker.plot_purity(config, signal_list = ["wjets_2211","wjets_2211_ASSEW","wjets_FxFx","wjets"], name_map=name_map, plot_response=False)

    unfolding.plot.make_eff_plots(config)



if __name__ == "__main__":
    main()
