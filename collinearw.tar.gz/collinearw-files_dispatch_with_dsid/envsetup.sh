#!/bin/bash

PYTHON_VER="3.9"
CURRENT_PLATFORM=$(uname -a)


case $CURRENT_PLATFORM in
  *"cent7"* | *"sdf"* | *"el7"* | *"slc6"*)
    case $CURRENT_PLATFORM in
      *"slc6"*)
        LCG_RELAESE="98bpython3"
        PLATFORM="x86_64-slc6-gcc8-opt"
      ;;

      *)
        LCG_RELAESE="102b_ATLAS_1"
        PLATFORM="x86_64-centos7-gcc12-opt"
      ;;
    esac
    CVMFS_VIEWS=/cvmfs/sft.cern.ch/lcg/views
    setupATLAS -q
    export PIP_NO_CACHE_DIR=off
    lsetup "views LCG_${LCG_RELAESE} ${PLATFORM}"
    TEMP_PYTHONPATH=$CVMFS_VIEWS}/LCG_${LCG_RELAESE}/${PLATFORM}/bin/python:${CVMFS_VIEWS}/LCG_${LCG_RELAESE}/${PLATFORM}/lib
  ;;

  *)
    export PIP_NO_CACHE_DIR=off
  ;;
esac

OLD_PYTHONPATH=$PYTHONPATH

if [ -f "py3/bin/activate" ]; then
    source py3/bin/activate
else
    python -m venv py3
    source py3/bin/activate
    PYTHONPATH=$TEMP_PYTHONPATH
    python -m pip install -U pip setuptools wheel
    cd collinearw
    echo 'Now run `python -m pip install -e .` or
        `python -m pip install -e .[unfolding]` or
        `python -m pip install -e .[complete]`'
    read -p "Press enter for basic install, or choose unfolding / complete: " answer
    case ${answer} in
        unfolding )
            python -m pip install -e .[unfolding]
        ;;
        complete )
            python -m pip install -e .[complete]
        ;;
        * )
            python -m pip install -e .
        ;;
    esac
    cd ..
fi
export PYTHONPATH=$(pwd)/py3/lib/python${PYTHON_VER}/site-packages:$OLD_PYTHONPATH
export ROOT_INCLUDE_PATH=$PWD/py3/include:$ROOT_INCLUDE_PATH
export LD_LIBRARY_PATH=$PWD/py3/lib:$LD_LIBRARY_PATH
