"""
Experimental, testing a database structure for accessing large ConfigMgr object
"""


class ConifgMgrView:
    pass
