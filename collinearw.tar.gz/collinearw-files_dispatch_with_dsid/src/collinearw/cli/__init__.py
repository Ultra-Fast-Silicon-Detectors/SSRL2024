""" The collinearw command line interface. """

from .cli import collinearw

__all__ = ['collinearw']
