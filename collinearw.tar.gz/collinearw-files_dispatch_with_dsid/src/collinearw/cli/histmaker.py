import click
import time
import logging
from .lazy_import import lazy_import as lazy

log = logging.getLogger(__name__)
run_HistMaker = lazy("collinearw.run_HistMaker")


@click.group(name='histmaker')
def cli():
    """entry point for HistMaker"""


@cli.command(name='run')
@click.option("--config", type=str, help="path to the configuration file (.py file).")
@click.option("--oname", type=str, help="output file name.")
@click.option("--batch-dir", default="./", type=str)
@click.option("--findex", multiple=True, type=str)
@click.option("--submit-batch/--no-submit-batch", default=False)
@click.option("--merge/--no-merge", default=False)
def run_histmaker(config, oname, batch_dir, findex, submit_batch, merge):
    """
    Given a config, reduce ntuples to histograms.
    """
    start = time.time()
    if merge:
        run_HistMaker.merge_output(config, oname)
    else:
        run_HistMaker.run_HistMaker(config, oname)
    log.info(f"cost {time.time() - start}")


'''
@cli.command()
@click.option("--config", type=str, help="path to the configuration file (.py file).")
@click.option("--oname", type=str, help="output file name.")
@click.option("--weight-obs", type=str)
@click.option("--weight-file", type=str)
@click.option("--scale_factor", type=float, default=1.0)
def weight_gen(config, oname, weight_obs, weight_file, scale_factor):
    """
    Given a config, reduce ntuples to histograms with addition of external weight distribution
    """
    start = time.time()
    run_HistMaker_weight_gen(config, oname, weight_obs, weight_file, scale_factor)
    log.info(f"cost {time.time() - start}")
'''
