# Use semantic versioning (https://semver.org/)
# The version number is controlled through bumpversion.cfg
__version__ = '1.3.0'
