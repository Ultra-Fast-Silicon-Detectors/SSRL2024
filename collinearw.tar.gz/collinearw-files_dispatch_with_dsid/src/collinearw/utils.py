import sys
import os
import warnings
import formulate
from contextlib import contextmanager
from functools import lru_cache

try:
    import yoda
except ImportError:
    warnings.warn("Cannot import yoda module!")
try:
    import ROOT
except ImportError:
    warnings.warn("Cannot import ROOT module!")


class RecursionLimit:
    __slot__ = ("old_limit", "limit")

    def __init__(self, limit):
        self.old_limit = sys.getrecursionlimit()
        self.limit = limit

    def __enter__(self):
        sys.setrecursionlimit(self.limit)

    def __exit__(self, exc_type, exc_val, exc_tb):
        sys.setrecursionlimit(self.old_limit)


@lru_cache(maxsize=None)
def from_root(expr, *, rlimit=1500):
    try:
        with RecursionLimit(rlimit):  # pyparsing can reach the limit for long expr
            return formulate.from_root(expr)
    except formulate.parser.ParsingException as _error:
        raise Exception(f"unable to parse {expr} due to pyparsing") from _error
    except Exception as _error:
        raise Exception(f"unable to parse {expr}") from _error


@lru_cache(maxsize=None)
def from_numexpr(expr):
    try:
        return formulate.from_numexpr(expr)
    except formulate.parser.ParsingException as _error:
        raise Exception(f"unable to parse {expr} due to pyparsing") from _error
    except Exception as _error:
        raise Exception(f"unable to parse {expr}") from _error


@lru_cache(maxsize=None)
def to_numexpr(expr):
    if expr:
        return from_root(expr).to_numexpr()
    return expr


@lru_cache(maxsize=None)
def _expr_var(expr):
    """
    converting ROOT expression into set of variables
    """
    for i in range(5):  # maximum attempt
        try:
            return set(from_root(expr).variables)
        except Exception as _err:
            if i < 4:
                continue
            raise _err


@contextmanager
def stdout_redirected(new_stdout=None):
    new_stdout = new_stdout or open(os.devnull, 'w')
    save_stdout = sys.stdout
    sys.stdout = new_stdout
    try:
        yield new_stdout
    finally:
        sys.stdout = save_stdout


@contextmanager
def root_redirected(new_path, mode="a"):
    ROOT.gSystem.RedirectOutput(new_path, mode)
    try:
        yield None
    finally:
        ROOT.gROOT.ProcessLine("gSystem->RedirectOutput(0);")


@contextmanager
def all_redirected(new_path=None, mode="a"):
    try:
        with stdout_redirected(new_path) as f:
            with root_redirected(f.name, mode):
                yield None
    finally:
        pass


def root2yoda(roothist, path=""):
    nbins = roothist.GetNbinsX()
    # xlow = roothist.GetBinLowEdge(1)
    # xhigh = roothist.GetBinLowEdge(nbins + 1)
    # yodahist = yoda.Histo1D(nbins, xlow, xhigh, path=path, title=roothist.GetTitle())
    bin_edges = []
    for i in range(1, nbins + 2):
        bin_edges.append(roothist.GetBinLowEdge(i))
    yodahist = yoda.Histo1D(bin_edges, path=path, title=roothist.GetTitle())
    for i in range(0, nbins):
        yodahist.fillBin(i, roothist.GetBinContent(i + 1) * roothist.GetBinWidth(i + 1))
    return yodahist


def yoda_write(*args, **kwargs):
    yoda.write(*args, **kwargs)
