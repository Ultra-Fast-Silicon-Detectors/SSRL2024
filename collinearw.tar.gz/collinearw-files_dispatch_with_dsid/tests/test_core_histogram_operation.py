import pytest
import numpy as np
from collinearw import Histogram, Histogram2D
import ROOT


def test_histogram_add():
    lbin_content = np.array([0, 1, 5, 7, 0])
    lsumW2 = np.array([0, 2, 4, 1, 0])
    rbin_content = np.array([0, 2, 4, 3, 0])
    rsumW2 = np.array([0, 3, 1, 2, 0])
    result_bin_content = lbin_content + rbin_content
    result_sumW2 = lsumW2 + rsumW2
    lhs = Histogram("lhs", 3, 0, 100, "x title")
    lhs.bin_content = lbin_content
    lhs.sumW2 = lsumW2
    rhs = Histogram("rhs", 3, 0, 100, "x title")
    rhs.bin_content = rbin_content
    rhs.sumW2 = rsumW2
    result = lhs + rhs
    assert (result.bin_content == result_bin_content).all()
    assert (lhs.bin_content == lbin_content).all()
    assert (rhs.bin_content == rbin_content).all()
    assert (result.sumW2 == result_sumW2).all()
    assert (lhs.sumW2 == lsumW2).all()
    assert (rhs.sumW2 == rsumW2).all()
    lhs.add(rhs)
    assert (lhs.bin_content == result_bin_content).all()
    assert (rhs.bin_content == rbin_content).all()
    assert (lhs.sumW2 == lsumW2 + rsumW2).all()
    assert (rhs.sumW2 == rsumW2).all()
    neg_const = -10
    result_neg_const = rbin_content + neg_const
    result_neg_const_sumW2 = rsumW2
    rhs.add(neg_const)
    assert (rhs.bin_content == result_neg_const).all()
    assert (rhs.sumW2 == result_neg_const_sumW2).all()
    pos_const = 10
    result_pos_const = result_neg_const + pos_const
    rhs.add(pos_const)
    assert (rhs.bin_content == result_pos_const).all()
    assert (rhs.sumW2 == result_neg_const_sumW2).all()
    with pytest.raises(TypeError):
        lhs.add("I am histogram!")
    with pytest.raises(TypeError):
        lhs.add((1, 2, 3))
    with pytest.raises(TypeError):
        lhs.add([1, 2, 3])


def test_histogram_sub():
    lbin_content = np.array([0, 1, 5, 7, 0])
    lsumW2 = np.array([0, 2, 4, 1, 0])
    rbin_content = np.array([0, 2, 4, 3, 0])
    rsumW2 = np.array([0, 3, 1, 2, 0])
    result_bin_content = lbin_content - rbin_content
    result_sumW2 = lsumW2 + rsumW2
    lhs = Histogram("lhs", 3, 0, 100, "x title")
    lhs.bin_content = lbin_content
    lhs.sumW2 = lsumW2
    rhs = Histogram("rhs", 3, 0, 100, "x title")
    rhs.bin_content = rbin_content
    rhs.sumW2 = rsumW2
    result = lhs - rhs
    assert (result.bin_content == result_bin_content).all()
    assert (lhs.bin_content == lbin_content).all()
    assert (rhs.bin_content == rbin_content).all()
    assert (result.sumW2 == result_sumW2).all()
    assert (lhs.sumW2 == lsumW2).all()
    assert (rhs.sumW2 == rsumW2).all()
    lhs.sub(rhs)
    assert (lhs.bin_content == result_bin_content).all()
    assert (rhs.bin_content == rbin_content).all()
    assert (lhs.sumW2 == lsumW2 + rsumW2).all()
    assert (rhs.sumW2 == rsumW2).all()
    neg_const = -10
    result_neg_const = rbin_content - neg_const
    result_neg_const_sumW2 = rsumW2
    rhs.sub(neg_const)
    assert (rhs.bin_content == result_neg_const).all()
    assert (rhs.sumW2 == result_neg_const_sumW2).all()
    pos_const = 10
    result_pos_const = result_neg_const - pos_const
    rhs.sub(pos_const)
    assert (rhs.bin_content == result_pos_const).all()
    assert (rhs.sumW2 == result_neg_const_sumW2).all()
    with pytest.raises(TypeError):
        lhs.sub("I am histogram!")
    with pytest.raises(TypeError):
        lhs.sub((1, 2, 3))
    with pytest.raises(TypeError):
        lhs.sub([1, 2, 3])


def test_histogram_to_root_cache():
    hist = Histogram("test", 1, 0, 1, "x title")
    root_hist = hist.root
    # check if another call to `root` returns the cached histogram or not
    assert root_hist == hist.root
    # check that histograms of the same name, but different properties don't get cached the same
    another_hist = Histogram("test", 10, -10, 10, "a different title")
    assert not root_hist == another_hist.root


def test_histogram_from_root():
    roothist = ROOT.TH1F("test_from_root", "test_from_root", 10, 0, 1)
    for i in range(0, 12):
        roothist.SetBinContent(i, i**2.0)

    hist = Histogram("test_from_root", 10, 0, 1, "x title")
    hist.root = roothist
    assert hist.bin_content.tolist() == [
        0.0,
        1.0,
        4.0,
        9.0,
        16.0,
        25.0,
        36.0,
        49.0,
        64.0,
        81.0,
        100.0,
        121.0,
    ]

    roothist2d = ROOT.TH2F("test_from_root2d", "test_from_root2d", 2, 0, 1, 1, 0, 1)
    for coord in np.ndindex((4, 3)):
        roothist2d.SetBinContent(*coord, np.square(coord).sum())

    hist2d = Histogram2D("test_from_root2d", "xvar", "yvar", 2, 0, 1, 1, 0, 1)
    hist2d.root = roothist2d
    assert hist2d.bin_content.tolist() == [
        [0.0, 1.0, 4.0],
        [1.0, 2.0, 5.0],
        [4.0, 5.0, 8.0],
        [9.0, 10.0, 13.0],
    ]
